package ProjetoN2.Ano5.Quiz;

import javax.swing.JOptionPane;

public class Contador {
    public static int contador = 0;
}


